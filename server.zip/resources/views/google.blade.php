@extends( "layouts.plantilla" )

	@section( "cabeza" )

		

	@endsection

	@section( "cuerpo" )

	{{$geocoder['lat']}}


    @endsection

	@section( "piepagina" )


	@endsection
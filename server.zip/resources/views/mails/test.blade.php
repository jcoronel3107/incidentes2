<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<h1>{{$titulo}}</h1>
<p>{{$contenido}}</p>
</body>
</html>
	@extends( "layouts.plantilla" )

	@section( "cabeza" )


	@endsection

	@section( "cuerpo" )
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded">Consulta Registro Información de Gasolineras</h2>
		<h2>{{$gasolinera->id}}</h2>
@endsection
@section( "piepagina" ) @endsection
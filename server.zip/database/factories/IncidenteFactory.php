<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Incidente;
use Faker\Generator as Faker;

$factory->define(Incidente::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

return [

    /*
     * Si esta a true, mostrará los lenguajes disponibles
     *
     * @var bool
     */
    'status' => true,

    /*
     * Lenguajes disponibles
    */
    'languages' => [
        

        'en'    => ['en', 'en_US', false],
        'es'    => ['es', 'es_ES', false],
    ],
];
<?php

return [
    'geocoding' => [
        'enabled' => true,
        'google-maps' => [
            'api-key' => env('AIzaSyDQWkyaqY4K2sOinX5crayMw6oVrg6LrwE'),
        ]
    ]
];
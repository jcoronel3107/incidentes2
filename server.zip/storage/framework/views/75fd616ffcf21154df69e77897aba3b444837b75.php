	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger">Consultar Información de Incidentes</h2>
		<?php if(Session::has('Registro_Borrado')): ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
			<?php echo e(session('Registro_Borrado')); ?>

			<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Actualizado')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('Registro_Actualizado')); ?>

			<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Almacenado')): ?>
		<div class="alert alert-primary alert-dismissible fade show" role="alert">
			<?php echo e(session('Registro_Almacenado')); ?>

			<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>

			<ul class="nav justify-content-end">
  <li class="nav-item"  >
  	<a class="btn btn-outline-danger" href="<?php echo e(route('incidente.create')); ?>">Nuevo</a>
    <a class="btn btn-outline-success" href="incidentes/export/">Exporta Excel</a>
  </li>

</ul>
<hr style="border:2px;">
<?php echo $__env->make('/incidente.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<table class="table table-hover">
			<thead>
				<tr>
					<td>Tipo_Incidente</td>
					<td>Nombre_Incidente</td>
					<td>created_at</td>
					<td>updated_at</td>
					<td>Opciones</td>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $incidentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($incidente->tipo_incidente); ?>&nbsp;</td>
					<td><?php echo e($incidente->nombre_incidente); ?>&nbsp;</td>
					<td><?php echo e($incidente->created_at); ?>&nbsp;</td>
					<td><?php echo e($incidente->updated_at); ?>&nbsp;</td>
					<td>
						<a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('incidente.edit',$incidente->id)); ?>" role="button">Edit</a>
						
					</td>

				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>
		<?php echo e($incidentes -> appends(['searchText' => $query]) -> links()); ?>

	<?php $__env->stopSection(); ?> <?php $__env->startSection( "piepagina" ); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//incidente/index.blade.php ENDPATH**/ ?>


	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
    <h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger">Importación Eventos 10-20</h2>
         <form class="form" action="/inundacions/import" method="post" enctype="multipart/form-data">
         	<?php echo csrf_field(); ?>
         	<input type="file" name="file">
         	<button>Importar Información</button>
         </form>
    <?php $__env->stopSection(); ?>

	<?php $__env->startSection( "piepagina" ); ?>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//inundacion/import.blade.php ENDPATH**/ ?>
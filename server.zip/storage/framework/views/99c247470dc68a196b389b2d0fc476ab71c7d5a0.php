	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger">Consultar Información de Evento Fugas</h2>

		<div class="card">
		  <div class="card-header ">
		    <div class="row">
		    	<div class="col-6"><h3>Registro Nro.<?php echo e($fuga->id); ?></h3>
		    	</div>
		    	<div class="col-6 text-right">
		    		<a href="<?php echo e(route('fuga.index')); ?>" class="btn btn-outline-primary ">Regresar</a>
		    	</div>
		    </div>
		  </div>
  <div class="card-body">
    	<div class="row p-3 border-left-primary">
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Cod_Incidente:</span>
				<p class="text-info"><?php echo e($fuga->incidente->nombre_incidente); ?></p>
			</div>
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Tipo_Escena:</span>
				<p class=" text-info"><?php echo e($fuga->tipo_escena); ?></p>
			</div>
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Cod_Estacion:</span>
				<p class=" text-info"><?php echo e($fuga->station_id); ?></p>
			</div>
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Fecha:</span>
				<p class="text-info"><?php echo e($fuga->fecha); ?></p>
			</div>
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Ficha_Ecu911:</span>
				<p class="text-info"><?php echo e($fuga->ficha_ecu911); ?></p>
			</div>
			<div class="col-2">
				<span class="bg-gray font-weight-bold">Hora_FichaEcu911:</span>
				<p class="text-info"><?php echo e($fuga->hora_fichaecu911); ?></p>
			</div>
		</div>
		<hr>
		<div class="row p-3">

			<div class="col-4">
				<span class="bg-gray font-weight-bold">Dirección:</span>
				 <p class="text-info"><?php echo e($fuga->direccion); ?></p>
				</div>

			<div class="col-4">
				<span class="bg-gray font-weight-bold">Parroquia: </span>
				<p class="text-info"><?php echo e($fuga->parroquia->nombre); ?></p>
			</div>
			<div class="col-4">
				<span class="bg-gray font-weight-bold">Geoposición:</span>
				<p class="text-info"><?php echo e($fuga->geoposicion); ?></p>
			</div>
		</div>
		<hr>
		<div class="row p-3 border-left-primary">

			<div class="col-3">
				<span class="bg-gray font-weight-bold">Hora Salida a Emergencia:</span>
				<p class="text-info"><?php echo e($fuga->hora_salida_a_emergencia); ?></p>
			</div>
			<div class="col-3">
				<span class="bg-gray font-weight-bold">Hora Llegada A Emergencia:</span>
				<p class="text-info"><?php echo e($fuga->hora_llegada_a_emergencia); ?></p>
			</div>
			<div class="col-3">
				<span class="bg-gray font-weight-bold">Hora Fin Emergencia:</span>
				<p class="text-info"><?php echo e($fuga->hora_fin_emergencia); ?></p>
			</div>
			<div class="col-3">
				<span class="bg-gray font-weight-bold">Hora En Base:</span>
				<p class="text-info"><?php echo e($fuga->hora_en_base); ?></p>
			</div>
		</div>
		<div class="row p-3 ">

			<div class="col-6">
				<span class="bg-gray font-weight-bold">Informacion Inicial:</span>
				<p class="text-info text-wrap text-break"><?php echo e($fuga->informacion_inicial); ?></p>
			</div>
			<div class="col-6">
				<span class="bg-gray font-weight-bold">Detalle Emergencia:</span>
				<p class="text-info text-wrap text-break"><?php echo e($fuga->detalle_emergencia); ?></p>
			</div>
		</div>
		<div class="row p-3 border-left-primary">
				<div class="col-md-4 ol-sm-12">

						<span class="bg-gray font-weight-bold">Tipo_Cilindro</span>
						<p class="text-info text-wrap text-break"><?php echo e($fuga->tipo_cilindro); ?></p>

				</div>
				<div class="col-md-4 ol-sm-12">

						<span class="bg-gray font-weight-bold">Color_Cilindro</span>
						<p class="text-info text-wrap text-break"><?php echo e($fuga->color_cilindro); ?></p>

				</div>
				<div class="col-md-4 col-sm-12">

						<span class="bg-gray font-weight-bold">Tipo_Fallo</span>
						<p class="text-info text-wrap text-break"><?php echo e($fuga->tipo_fallo); ?></p>

				</div>
		</div>
		<hr>
		<div class="row p-3 ">

			<div class="col-6">
				<span class="bg-gray font-weight-bold">Usuario Afectado:</span>
				<p class="text-info"><?php echo e($fuga->usuario_afectado); ?></p>
			</div>
			<div class="col-6">
				<span class="bg-gray font-weight-bold"> Danos Estimados:</span>
				<p class="text-info text-wrap text-break"><?php echo e($fuga->danos_estimados); ?></p>
			</div>
		</div>
		<hr>
		<div class="row p-3 border-left-primary">

			<div class="col-4">
				<span class="bg-gray font-weight-bold"> Usuario Elabora:</span>
				<p class="text-info"><?php echo e($fuga->usr_creador); ?></p>
			</div>
			<div class="col-4">
				<span class="bg-gray font-weight-bold"> Usuario Edición:</span>
				<p class="text-info"><?php echo e($fuga->usr_editor); ?></p>
			</div>
			<div class="col-4">
				<span class="bg-gray font-weight-bold"> Fechas Creación:</span>
				<p class="text-info"><?php echo e($fuga->created_at); ?></p>
				<span class="bg-gray font-weight-bold"> Fechas Edición:</span>
				<p class="text-info"><?php echo e($fuga->updated_at); ?></p>
			</div>
		</div>
		<hr>
		<div class="row p-3">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<p class="text-center"><h4>Personal Asiste</h4></p>
				<table class="table table-sm table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Nombre</th>
				      <th scope="col">Cargo</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php $__currentLoopData = $fuga->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <tr>
				      <th scope="row"><?php echo e($user->id); ?></th>
				      <td><?php echo e($user->name); ?></td>
				      <td><?php echo e($user->cargo); ?></td>

				    </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </tbody>
				</table>
			</div>
		</div>
		<hr>
		<div class="row p-3">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<p class="text-center"><h4>Vehiculos En Incidente</h4></p>
				<table class="table table-sm table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Codigo</th>
				      <th scope="col">Placa</th>
				      <th scope="col">Marca</th>
				      <th scope="col">Km_Salida</th>
				      <th scope="col">Km_Llegada</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php $__currentLoopData = $fuga->vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <tr>
				      <th scope="row"><?php echo e($vehiculo->id); ?></th>
				      <td><?php echo e($vehiculo->codigodis); ?></td>
				      <td><?php echo e($vehiculo->placa); ?></td>
				      <td><?php echo e($vehiculo->marca); ?></td>
				      <td><?php echo e($vehiculo->pivot->km_salida); ?></td>
				      <td><?php echo e($vehiculo->pivot->km_llegada); ?></td>
				    </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </tbody>
				</table>
			</div>
		</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views/fuga/show.blade.php ENDPATH**/ ?>
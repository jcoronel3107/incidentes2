

<?php $__env->startSection( "cabeza" ); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection( "cuerpo" ); ?>
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active" id="General-tab" data-toggle="tab" href="#General" role="tab" aria-controls="General" aria-selected="true">General</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="Inundaciones-tab" data-toggle="tab" href="#Inundaciones" role="tab" aria-controls="Inundaciones" aria-selected="true">Inundaciones</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="Rescates-tab" data-toggle="tab" href="#Rescates" role="tab" aria-controls="Rescates" aria-selected="false">Rescates</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="Transito-tab" data-toggle="tab" href="#Transito" role="tab" aria-controls="Transito" aria-selected="false">Transito</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="Salud-tab" data-toggle="tab" href="#Salud" role="tab" aria-controls="Salud" aria-selected="false">Salud</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="Fuego-tab" data-toggle="tab" href="#Fuego" role="tab" aria-controls="Fuego" aria-selected="false">Fuego</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="F-Gas-tab" data-toggle="tab" href="#F-Gas" role="tab" aria-controls="F-Gas" aria-selected="false">F-Gas</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  
  <div class="tab-pane fade show active" id="General" role="tabpanel" aria-labelledby="General-tab">
  		<div class="row">
  			<div class="col-xl-8 col-lg-8">

				<div class="py-2 " id="container0"></div>

			</div>

			<div class="col-xl-4 col-lg-4">

				<div class="py-2 " id="table0.1">
					<table class="table table-sm" id="datatable0.1">
				        <thead>
				            <tr>
				            	<th class="table-dark">Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $EventosxIncidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->nombre_incidente)); ?></td>
				                <td class="table-light"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
  			<div class="col-xl-8 col-lg-8">

				<div class="py-2 " id="container0.2"></div>

			</div>

			<div class="col-xl-4 col-lg-4">

				<div class="py-2 " id="table0.2">
					<table class="table table-sm" id="datatable0.2">
				        <thead>
				            <tr>
				            	<th class="table-dark">Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $EventosMensuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
  </div>
  
  <div class="tab-pane fade show " id="Inundaciones" role="tabpanel" aria-labelledby="Inundaciones-tab">
  		<div class="row">
  			<div class="col-xl-10 col-lg-10">

				<div class="py-2 " id="container1"></div>

			</div>

			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table1.1">
					<table class="table table-sm" id="datatable1.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesInundacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-6 col-lg-6">
				<h3>Tipos Inundaciones</h3>
				<div class="py-2" id="table1.2">
					<table class="table table-sm" id="datatable1.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Inundacionxincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-warning"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-warning"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container1.2"></div>
			</div>
			
			<div class="col-xl-6 col-lg-6">
				<h3>Asistencias x Estación</h3>
				<div class="py-2" id="table1.3">
					<table class="table table-sm" id="datatable1.3">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Inundacionxestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container1.3"></div>
			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-4 col-lg-4">
				<h3>Inundaciones por Parroquia</h3>
				<div class="py-2" id="table1.4">

					<table class="table table-sm" id="datatable1.4">
				        <thead>
				            <tr>
				                <th class="table-dark">Parroquia</th>
				                <th class="table-dark">Incidentes</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Inundacionxparroquia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e($registro->nombre); ?></td>
				                <td class="table-light"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>

				</div>

			</div>
			<div class="col-xl-8 col-lg-4 py-8" id="container1.4"></div>
		</div>
  </div>
  
  <div class="tab-pane fade" id="Rescates" role="tabpanel" aria-labelledby="Rescates-tab">
  		<div class="row">
			<div class="col-xl-10 col-lg-10">
				<div class="py-2" id="container2"></div>
			</div>
			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table2.0">
					<table class="table table-sm" id="datatable2.0">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesRescate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			<div class="col-sm-6 col-lg-6">
				<h3>Tipos Rescates</h3>
				<div class="py-2" id="table2.1">
					<table class="table table-sm" id="datatable2.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Rescatexincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container2.1"></div>
			</div>
			<div class="col-xl-6 col-lg-6">
				<h3>Asitencias por Estación</h3>
				<div class="py-2" id="table2.2">
					<table class="table table-sm" id="datatable2.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Rescatexestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container2.2"></div>
			</div>
		</div>
  </div>
  
  <div class="tab-pane fade" id="Transito" role="tabpanel" aria-labelledby="Transito-tab">
  		<div class="row">
			<div class="col-xl-10 col-lg-10">

				<div class="py-2" id="container3"></div>

			</div>
			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table3">
					<table class="table table-sm" id="datatable3">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesTransito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-warning"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-warning"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table3.1">
					<table class="table table-sm" id="datatable3.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Transitoxincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-warning"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-warning"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container3.1"></div>
			</div>
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table3.2">
					<table class="table table-sm" id="datatable3.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Transitoxestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container3.2"></div>
			</div>
		</div>
  </div>
  
  <div class="tab-pane fade" id="Salud" role="tabpanel" aria-labelledby="Salud-tab">
  		
  		<div class="row">
			<div class="col-xl-10 col-lg-10">

				<div class="py-2" id="container4"></div>

			</div>
			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table4">
					<table class="table table-sm" id="datatable4">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesSalud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table4.1">
					<table class="table table-sm" id="datatable4.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Saludxincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container4.1"></div>
			</div>
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table4.2">
					<table class="table table-sm" id="datatable4.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Saludxestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container4.2"></div>
			</div>
		</div>
  </div>
  
  <div class="tab-pane fade" id="Fuego" role="tabpanel" aria-labelledby="Fuego-tab">
  		
  		<div class="row">
			<div class="col-xl-10 col-lg-10">

				<div class="py-2" id="container5"></div>

			</div>
			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table5">
					<table class="table table-sm" id="datatable5">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesFuego; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table5.1">
					<table class="table table-sm" id="datatable5.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Fuegoxincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container5.1"></div>
			</div>
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table5.2">
					<table class="table table-sm" id="datatable5.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Fuegoxestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container5.2"></div>
			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-4 col-lg-4">
				<h3>Incendios por Parroquia</h3>
				<div class="py-2" id="table5.3">

					<table class="table table-sm" id="datatable5.3">
				        <thead>
				            <tr>
				                <th class="table-dark">Parroquia</th>
				                <th class="table-dark">Incidentes</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Incendiosxparroquia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e($registro->nombre); ?></td>
				                <td class="table-light"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>

				</div>

			</div>
			<div class="col-xl-8 col-lg-4 py-8" id="container5.3"></div>
		</div>
  </div>
  
  <div class="tab-pane fade" id="F-Gas" role="tabpanel" aria-labelledby="F-Gas-tab">
  		
  		<div class="row">
			<div class="col-xl-10 col-lg-10">

				<div class="py-2" id="container6"></div>

			</div>
			<div class="col-xl-2 col-lg-2">

				<div class="py-2 " id="table6">
					<table class="table table-sm" id="datatable6">
				        <thead>
				            <tr>
				                <th class="table-dark">Mes</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $mensualesGas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-light"><?php echo e(($registro->Mes)); ?></td>
				                <td class="table-light"><?php echo e($registro->count); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>

			</div>
		</div>
		<div class="row">
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table6.1">
					<table class="table table-sm" id="datatable6.1">
				        <thead>
				            <tr>
				                <th class="table-dark">Nombre Incidente</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Gasxincidente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->nombre_incidente); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container6.1"></div>
			</div>
			
			<div class="col-xl-6 col-lg-6">
				<div class="py-2" id="table6.2">
					<table class="table table-sm" id="datatable6.2">
				        <thead>
				            <tr>
				                <th class="table-dark">Estacion</th>
				                <th class="table-dark">Asistencias</th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__currentLoopData = $Gasxestacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td class="table-info"><?php echo e($registro->station_id); ?></td>
				                <td class="table-info"><?php echo e($registro->salidas); ?></td>
				            </tr>
 							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
				<div class="py-2" id="container6.2"></div>
			</div>
		</div>
  </div>
	</div>



<?php $__env->startPush('scripts'); ?>
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script src="https://code.highcharts.com/modules/data.js"></script>
	<script src="https://code.highcharts.com/modules/exporting.js"></script>
	<script src="https://code.highcharts.com/modules/accessibility.js"></script>
	
	<script >
		Highcharts.chart('container0', {
		    		data: {
		        table: 'datatable0.1',
		        name:'Incidentes',
		    },
		    chart: {
 				plotBackgroundColor: null,
        		plotBorderWidth: null,
        		plotShadow: false,
		        type: 'pie'
		    },
		    title: {
		        text: 'Incidentes Por Tipo (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		    	pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
		         /*formatter: function() {
    			    return 'Cant <b>' + this.y ;
   				 }*/
		    }
		});
	</script>
	<script >
		Highcharts.chart('container0.2', {

		    series: [{
        		type: 'areaspline',
        		name: 'Inundacion',
		        data: [3, 2, 1, 0, 4,10,8, 5, 12, 31]
	    	}, {
    		    type: 'areaspline',
        		name: 'Rescate',
        		data: [2, 3, 5, 7, 6,10,8, 5, 12, 31]
		    }, {
		        type: 'areaspline',
		        name: 'Transito',
		        data: [4, 3, 3, 9, 0,4, 3, 3, 9, 10]
    		},{
        		type: 'areaspline',
        		name: 'Salud',
		        data: [14, 14, 13, 19, 10,8, 5, 12, 31, 45]
	    	},{
        		type: 'areaspline',
        		name: 'Fuego',
		        data: [15, 22, 11, 33, 24,13, 21, 11, 23, 14]
	    	},{
        		type: 'areaspline',
        		name: 'Fuga',
		        data: [13, 21, 11, 23, 14,11, 23, 14,13, 21]
	    	},{
        		type: 'areaspline',
        		name: 'Derrame',
		        data: [3, 21, 12, 3, 14,21, 11, 23, 14,11]
	    	}],

		    title: {
		        text: 'Eventos (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Cant <b>' + this.y ;
   				 }
		    },
		    plotOptions: {
       			 areaspline: {
        		    fillOpacity: 0.4
      			  }
    		}
		});
	</script>
	
	<script >
		Highcharts.chart('container1', {
		    		data: {
		        table: 'datatable1.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Inundaciones (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container1.2', {
		    		data: {
		        table: 'datatable1.2',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Tipo Inundacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container1.3', {
		    		data: {
		        table: 'datatable1.3'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Inundación por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container1.4', {
		    data: {
		        table: 'datatable1.4'
		    },
		    chart: {
		        type: 'area'
		    },
		    title: {
		        text: 'Asistencias Inundación por Parroquia (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>

	
	<script >
		Highcharts.chart('container2', {
		    		data: {
		        table: 'datatable2.0',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Tipo Rescate (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container2.1', {
		    		data: {
		        table: 'datatable2.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Tipo Rescate (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container2.2', {
		    		data: {
		        table: 'datatable2.2'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Rescate por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>

	
	<script >
		Highcharts.chart('container3', {
		    		data: {
		        table: 'datatable3',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Transito (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container3.1', {
		    		data: {
		        table: 'datatable3.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Tipo Transito (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container3.2', {
		    		data: {
		        table: 'datatable3.2'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Transito por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>

	
	<script >
		Highcharts.chart('container4', {
		    		data: {
		        table: 'datatable4',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Salud (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container4.1', {
		    		data: {
		        table: 'datatable4.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Salud (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container4.2', {
		    		data: {
		        table: 'datatable4.2'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Salud por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>

	
	<script >
		Highcharts.chart('container5', {
		    		data: {
		        table: 'datatable5',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Fuego (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container5.1', {
		    		data: {
		        table: 'datatable5.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Fuego (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container5.2', {
		    		data: {
		        table: 'datatable5.2'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Fuego por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container5.3', {
		    		data: {
		        table: 'datatable5.3'
		    },
		    chart: {
		        type: 'area'
		    },
		    title: {
		        text: 'Asistencias Fuego por Parroquia (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Parroquia <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>

	
	<script >
		Highcharts.chart('container6', {
		    		data: {
		        table: 'datatable6',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'line'
		    },
		    title: {
		        text: 'Fuga (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Mes <b>' + this.x + '</b>, tiene <b>' + this.y + '</b> Asistencias ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container6.1', {
		    		data: {
		        table: 'datatable6.1',
		        name:'Incidentes',
		    },
		    chart: {
		        type: 'bar'
		    },
		    title: {
		        text: 'Fuga (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return  this.y + '</b>, Incidentes ';
   				 }
		    }
		});
	</script>
	<script >
		Highcharts.chart('container6.2', {
		    		data: {
		        table: 'datatable6.2'
		    },
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Asistencias Fuga por Estacion (Anual)'
		    },
		    subtitle:{
						text: 'Grafica'
			},
		    yAxis: {
		        allowDecimals: false,
		        title: {
		            text: 'Units'
		        }
		    },
		    tooltip: {
		         formatter: function() {
    			    return 'Estacion <b>' + this.x + '</b> tiene <b>' + this.y + '</b>, Asistencias ';
   				 }
		    }
		});
	</script>


	<script type="text/javascript">
		function EnviarInfo(accion,objReserva){
                  $.ajax(
                    {
                    type:"POST",
                    url:"<?php echo e(url('user.reservations.store')); ?>"+accion,
                    data:objReserva,
                    success:function(msg){
                        console.log(msg);

                        $('#exampleModal').modal('toggle');
                        calendar.refetchEvents();
                    },
                    error:function(){alert("Hay un Error");}

                    }
                  );
        }
        $('#btnGrafico2').click(function(){
                  objReserva = recolectardatosGUI("POST");
                  EnviarInfo(accion,objReserva)
        });

        function recolectardatosGUI(method){
                  nuevaReserva={
                    desdeInundacion:$('#FechaDesdeInundacion').val(),
                    hastaInundacion:$('#FechaHastaInundacion').val(),
                    '_token':$("input[name='_token']").attr('content'),
                    '_method':method
                  }
                  return (nuevaReserva);
        }
	</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//consulta/estadisticas.blade.php ENDPATH**/ ?>
	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger">Consultar Información de Estación Servicio</h2>
		<?php if(Session::has('Registro_Borrado')): ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Borrado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Actualizado')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Actualizado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Almacenado')): ?>
		<div class="alert alert-primary alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Almacenado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<ul class="nav justify-content-end">
		 <li class="nav-item">
		     <a class="btn btn-outline-danger" href="gasolinera/create">Nuevo</a>
		      <a class="btn btn-outline-success" href="inundacions/export/">Exporta Excel</a>
		 </li>
		</ul>
		<hr style="border:2px;">
		<?php echo $__env->make('gasolinera.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<table class="table table-hover ">
			<thead>
				<tr>
					<td>RazonSocial</td>
					<td>Ruc</td>
					<td>Direccion</td>
					<td>Email</td>
					<td>Opciones</td>
				<tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $gasolineras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasolinera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($gasolinera->razonsocial); ?></td>
					<td><?php echo e($gasolinera->ruc); ?></td>
					<td><?php echo e($gasolinera->direccion); ?></td>
					<td><?php echo e($gasolinera->email); ?></td>
					<td><a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('gasolinera.edit',$gasolinera->id)); ?>" role="button">Edit</a>
						<a class="btn btn-outline-info btn-sm" href="<?php echo e(route('gasolinera.show',$gasolinera->id)); ?>" role="button">Ver</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php echo e($gasolineras -> appends(['searchText' => $query]) -> links()); ?>

<?php $__env->stopSection(); ?> <?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//gasolinera/index.blade.php ENDPATH**/ ?>
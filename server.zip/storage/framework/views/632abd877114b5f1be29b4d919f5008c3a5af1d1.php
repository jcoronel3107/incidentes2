	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded">Consultar Información de Vehiculos</h2>
		<?php if(Session::has('Registro_Borrado')): ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Borrado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Actualizado')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Actualizado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Almacenado')): ?>
		<div class="alert alert-primary alert-dismissible fade show" role="alert">
		<?php echo e(session('Registro_Almacenado')); ?>

		<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<ul class="nav justify-content-end">
		  <li class="nav-item">
		    <a class="btn btn-outline-danger" href="vehiculo/create">Nuevo</a>
		    <a class="btn btn-outline-success" href="vehiculos/export/">Exporta Excel</a>
		    <a class="btn btn-outline-success" href="vehiculos/grafic/">Grafica</a>
		    <a class="btn btn-outline-success" href="/vehiculos/importar">Importar</a>

		  </li>
		</ul>
		<hr style="border:2px;">
		<?php echo $__env->make('vehiculo.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<table class="table table-hover">
			<thead>
				<tr>
					<td>Codigodis</td>
					<td>Placa</td>
					<td>Marca</td>
					<td>Modelo</td>
					<td>Clase</td>
					<td>Motor</td>
					<td>Chasis</td>
					<td>Opciones</td>
			</thead>
			<tbody>
				<?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($vehiculo->codigodis); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->placa); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->marca); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->modelo); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->clase); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->motor); ?>&nbsp;</td>
					<td><?php echo e($vehiculo->chasis); ?>&nbsp;</td>
					<td>
						<a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('vehiculo.edit',$vehiculo->id)); ?>" role="button">Edit</a>
						<a class="btn btn-outline-info btn-sm" href="<?php echo e(route('vehiculo.show',$vehiculo->id)); ?>" role="button">Ver</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
			</tbody>
		</table>
		<?php echo e($vehiculos -> appends(['asc' => request('asc')]) -> links()); ?>


<?php $__env->stopSection(); ?> <?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//vehiculo/index.blade.php ENDPATH**/ ?>
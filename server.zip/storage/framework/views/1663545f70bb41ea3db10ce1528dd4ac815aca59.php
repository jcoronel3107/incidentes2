	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger">Registro Información de Clave_14</h2>

		<form method="post" action="/clave">

			<div class="form-row">
				<?php echo e(csrf_field()); ?>

				<div class="form-group input-group  col-md-8">
					<div class="input-group-prepend">
						<span class="input-group-text">Estaciòn Servicio</span>
					</div>
					<select class="form-control selectpicker" name="gasolinera_id" data-live-search="true">
						<option selected>Elija...</option>
						<?php $__currentLoopData = $gasolineras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasolinera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option><?php echo e($gasolinera->razonsocial); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>


			</div>
			<div class="form-row">
				<div class="form-group input-group  col-md-8">
					<div class="input-group-prepend">
						<span class="input-group-text">Vehìculo</span>
					</div>
					<select class="form-control selectpicker" name="vehiculo_id" data-live-search="true">
						<option selected>Elija...</option>
						<?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option><?php echo e($vehiculo->codigodis); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="form-row">
				<div class="form-group input-group  col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text">Km. Salida del Vehìculo</span>
					</div>
					<input type="number" name="km_salida" placeholder="Km. Salida" class="form-control">
				</div>
				<div class="form-group input-group  col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text">Km. en Gasolinera</span>
					</div>
					<input type="number" required name="km_gasolinera" class="form-control" placeholder="Km. en Gasolinera">
				</div>
				<div class="form-group input-group col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text" id="kmllegada">Km. Llegada Vehìculo</span>
					</div>
					<input type="number" required name="km_llegada" class="form-control" id="kmllegada" placeholder="Km. Retorno">
				</div>
			</div>
			<div class="form-row">




			</div>
			<div class="form-row">
				<div class="form-group  input-group col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text" id="inputDolares">Dòlares</span>
					</div>
					<input type="number" required name="dolares" class="form-control" id="dolares" placeholder="Valor $ de Carga combustible">
				</div>
				<div class="form-group input-group  col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text">Galones</span>
					</div>
					<input type="number" name="galones" class="form-control" id="galones" placeholder="Galones de Carga combustible">
				</div>
				<div class="form-group input-group col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text">Combustible</span>
					</div>
					<select class="form-control" name="combustible">
						<option selected>Choose...</option>
						<option>Diesel</option>
						<option>Eco</option>
						<option>Super</option>
					</select>
				</div>
			</div>
			<div class="form-row">

				<div class="form-group input-group col-md-8">
					<div class="input-group-prepend">
						<span class="input-group-text">Conductor</span>
					</div>
					<select class="form-control" name="user_id">
						<option selected>Choose...</option>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option><?php echo e($user->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group input-group  col-md-4">
					<div class="input-group-prepend">
						<span class="input-group-text">Orden</span>
					</div>
					<input type="number" min="0" name="Orden" class="form-control" id="Orden" placeholder="#Orden Fisica">
				</div>

			</div>

			<div class="form-group">
				<button type="submit" name="Enviar" value="Enviar" class="btn btn-success">Registrar</button>
				<a class="btn btn btn-primary" role="button"
					href="<?php echo e(route('clave.index')); ?>">Cancelar
				</a>
				<button type="reset" name="Borrar" value="Borrar" class="btn btn-danger">Borrar Formulario</button>
			</div>
		</form>

		<?php if(count($errors)>0): ?> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="alert alert-danger" role="alert">
			<?php echo e($error); ?>

		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>


<?php $__env->stopSection(); ?> <?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//clave/crear.blade.php ENDPATH**/ ?>
	

	<?php $__env->startSection( "cabeza" ); ?>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection( "cuerpo" ); ?>
		<h2 class="mt-5 shadow p-3 mb-5 bg-white rounded text-danger"><?php echo trans('messages.Consult Traffic Accident Information'); ?></h2>
		<?php if(Session::has('Envio Mail Correcto')): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('Envio Mail Correcto')); ?>

			<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Importacion_Correcta')): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('Importacion_Correcta')); ?>

			<button type="button"
				class="close"
				data-dismiss="alert"
				aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		<?php endif; ?>
		<?php if(Session::has('Registro_Borrado')): ?>
			<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<?php echo e(session('Registro_Borrado')); ?>

				<button type="button"
					class="close"
					data-dismiss="alert"
					aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		<?php endif; ?>
		<?php if(Session::has('Registro_Actualizado')): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				<?php echo e(session('Registro_Actualizado')); ?>

				<button type="button"
					class="close"
					data-dismiss="alert"
					aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		<?php endif; ?>
		<?php if(Session::has('Registro_Almacenado')): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				<?php echo e(session('Registro_Almacenado')); ?>

				<button type="button"
					class="close"
					data-dismiss="alert"
					aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		<?php endif; ?>
		<ul class="nav justify-content-end">
		  <li class="nav-item">
		  	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create evento')): ?>
		    <a class="btn btn-outline-info" data-toggle="tooltip" title="Nuevo" href="transito/create"><i class="icon-plus icon-2x"></i></a>
		    <?php endif; ?>
		    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow export')): ?>
		    <a class="btn btn-outline-info" data-toggle="tooltip" title="Export" href="transitos/export/"><i class="icon-download-alt icon-2x"></i></a>
		    <?php endif; ?>
		    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow import')): ?>
		    <a class="btn btn-outline-info" data-toggle="tooltip" title="Import" href="/transitos/importar"><i class="icon-cloud-upload icon-2x"></i></a>
		    <?php endif; ?>
		    <a class="btn btn-outline-info" data-toggle="tooltip" title="Estadistica" href="transitos/grafic/"><i class="icon-filter icon-2x"></i> </a>
		  </li>
		</ul>
		<hr style="border:2px;">

		<?php echo $__env->make('transito.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<table class="table table-hover table-condensed">
			<thead>
				<tr class="table-primary">

					<th>Incidente</th>
					<th>Estacion</th>
					<th>Fecha</th>
					<th>Direccion</th>
					<th>Ficha_Ecu911</th>
					<th>Opciones</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $transitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>

					<td><?php echo e($transito->incidente->nombre_incidente); ?></td>
					<td><?php echo e($transito->station->nombre); ?></td>
					<td><?php echo e($transito->fecha); ?></td>
					<td><?php echo e($transito->direccion); ?></td>
					<td><?php echo e($transito->ficha_ecu911); ?></td>
					<td>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit evento')): ?>
						<a class="btn btn-outline-info btn-sm " data-toggle="tooltip" title="Edit" href="<?php echo e(route('transito.edit',$transito->id)); ?>"><i class="icon-edit"></i></a>
						<?php endif; ?>
						<a class="btn btn-outline-info btn-sm" data-toggle="tooltip" title="Ver" href="<?php echo e(route('transito.show',$transito->id)); ?>" role="button"><i class="icon-search"></i></a>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('send mail')): ?>
						<a class="btn btn-outline-info btn-sm" data-toggle="tooltip" title="Enviar" href="<?php echo e(action('MailController@SendMailsTransito', $transito->id)); ?>" role="button"><i class="icon-envelope"></i></a>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create pdf')): ?>
						<a class="btn btn-outline-info btn-sm" data-toggle="tooltip" title="PDF" href="<?php echo e(action('TransitoController@downloadPDF', $transito->id)); ?>" role="button"><i class="icon-file-text"></i></a>
						<?php endif; ?>

				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
			<tfoot>
				<tr class="table-primary">
					<td>Incidente</td>
					<td>Estacion</td>
					<td>Fecha</td>
					<td>Direccion</td>
					<td>Ficha_Ecu911</td>
					<td>Opciones</td>
				</tr>
			</tfoot>
		</table>
		<?php echo e($transitos -> appends(['searchText' => $query]) -> links()); ?>


<?php $__env->stopSection(); ?> <?php $__env->startSection( "piepagina" ); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make( "layouts.plantilla" , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/incidentes2/resources/views//transito/index.blade.php ENDPATH**/ ?>

<form method="get" action="/fuga" autocomplete="off" role="search" >
<div class="form-group col-12">
	<div class="input-group ">
		<input type="text" class="form-control" value="<?php echo e($query); ?>" name="searchText" placeholder="Buscar x Fecha..." >
		<span class="input-group-append">
			<button type="submit" class="btn btn-primary">Buscar</button>
		</span>
	</div>
</div>
</form>
<?php /**PATH /home/vagrant/incidentes2/resources/views/fuga/search.blade.php ENDPATH**/ ?>